import { withInstall } from '/@/utils';
import countTo from './src/CountTo.vue';

export const CountTo = withInstall(countTo);
