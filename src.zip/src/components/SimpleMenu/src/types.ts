export interface MenuState {
  activeName: string;
  openNames: string[];
  activeSubMenuNames: string[];
}
