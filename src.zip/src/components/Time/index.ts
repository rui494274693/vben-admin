import { withInstall } from '/@/utils/index';
import time from './src/Time.vue';

export const Time = withInstall(time);
